
import React, { useState } from 'react'
import ChildMouseTracker from './ChildMouseTracker';

function MouseTracker() {
    const [position,setPosition] = useState({x:0,y:0});
    function mouseMove(e){
setPosition({x:e.clientX, y:e.clientY})
} 
 return (
    <div onMouseMove={mouseMove} className='bg-slate-400'>
    <ChildMouseTracker position={position}/>

    </div>
  )
}

export default MouseTracker
