import React from 'react'

function ChildMouseTracker({position}) {
    let {x,y} = position;
  return (

    <div>
      <h1>the x and y cordinates of the moving mouse is:</h1>
      <p>{x}</p>
      <p>{y}</p>
    </div>
  )
}

export default ChildMouseTracker
