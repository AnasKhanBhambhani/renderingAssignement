import React, { Component } from 'react';

const WithLogger = (WrappedComponent) => {
  return class extends Component {
    componentDidMount() {
      console.log(`Component ${WrappedComponent.name} mounted`);
      console.log('Initial props:', this.props);
    }

    componentDidUpdate(prevProps) {
      console.log(`Component ${WrappedComponent.name} updated`);
      console.log('Previous props:', prevProps);
      console.log('Current props:', this.props);
    }

    componentWillUnmount() {
      console.log(`Component ${WrappedComponent.name} will unmount`);
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };
};

export default WithLogger;
