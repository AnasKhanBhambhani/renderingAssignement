import React, { Component } from 'react'
import withLogger from '../Hoc/WithLogger';

export class LifeCycle extends Component{
    constructor(){
        super();
        this.state = {
            show: false
        }
    }
    componentDidMount() {
        console.log('component created');
    }
    componentDidUpdate() {
        console.log('component updated');
    }
    componentWillUnmount() {
        console.log('component is unmounted');
    }
    render() {
        let data = {
            name: 'anas',
            age: 22,
            deprt: 'BSCS',
            section: "B"

        }
        return (
            <div className='bg-slate-400 w-36 flex flex-col items-center p-2 gap-4'>
                <div className='flex flex-col gap-3'>
                    <h2>Name: {data.name}</h2>
                    <p>Age: {data.age}</p>
                    {
                        this.state.show &&
                        (<div> <p>Deprt: {data.deprt}</p>
                            <p>Section: {data.section}</p></div>)

                    }


                </div>
                <div>
                    <button className='bg-amber-300 p-2 rounded-lg' onClick={() => this.setState({ show: !this.state.show })}>Show Detail</button>
                </div>

            </div>
        )
    }
}

export default withLogger(LifeCycle)
