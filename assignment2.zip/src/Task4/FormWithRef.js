import React, { useRef } from 'react'

const FormWithRef = () => {
    const Nameref = useRef();
    const Emailref = useRef();

    function handleForm(e){
e.preventDefault();
        if(!Nameref.current.value || !Emailref.current.value){
            alert('plz fillOut the both fields')
            return;
        }
    if(!(/\S+@\S+\.\S+/).test(Emailref.current.value)){ 
        alert('plz fillOut the valid Email');
        return;
    }
   alert('login successfully....')
   Nameref.current.value = '';
   Emailref.current.value = '';
    }
  return (
    <div>
      <form action="#" className='flex flex-col gap-3' onSubmit={handleForm}>
      <input ref={Nameref} type="text" name='name' required  placeholder='Enter your Name'/>
      <input ref={Emailref} type="email" name='email'  required placeholder='Enter Your Email'/>
      <button className='btn p-3 bg-orange-700' type='submit'>submit</button>
      </form>
    </div>
  )
}

export default FormWithRef
