import React, { useState } from 'react'

const InterectiveButton = () => {
    const [click, setClick] = useState(false);
    const [hover, setHover] = useState(false);
    const [doubleClick, setDoubleclick] = useState(false);

    function handleClick() {
        setClick(true);
    }
    function handleEnter() {
        setHover(true);
    }
    function handleLeave() {
        setHover(false);
    }
    return (
        <div>
            <button
                onClick={()=>{setClick(true)}}
                onMouseEnter={()=>{setHover(true)}}
                onMouseLeave={()=>{setHover(false)}}
                onDoubleClick={()=>{setDoubleclick(true)}}

                className={`${click && 'bg-orange-950'} ${hover && 'p-4'} ${doubleClick && 'rotate-45'} border border-lime-300`} >click me</button>
        </div>
    )
}

export default InterectiveButton
