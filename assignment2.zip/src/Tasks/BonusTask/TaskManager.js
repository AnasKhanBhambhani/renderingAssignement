import React, { useState } from 'react';

const TaskManager = () => {
    const [tasks, setTasks] = useState([]);
    const [taskName, setTaskName] = useState('');

    const addTask = () => {
        if (taskName === '') return;
        const newTask = { id: tasks.length + 1, name: taskName, completed: false };
        setTasks([...tasks, newTask]);
        setTaskName('');
    };

    const completeTask = (id) => {
        const updatedTasks = tasks.map(task => task.id === id ? { ...task, completed: true } : task);
        console.log(updatedTasks);
        setTasks(updatedTasks);
    };

    const removeTask = (id) => {
        const updatedTasks = tasks.filter(task => task.id !== id);
        setTasks(updatedTasks);
    };

    const sortByName = () => {
        const sortedTasks = [...tasks].sort((a, b) => a.name.localeCompare(b.name));
        setTasks(sortedTasks);
    };

    const sortByStatus = () => {
        const sortedTasks = [...tasks].sort((a, b) => (a.completed === b.completed ? 0 : a.completed ? -1 : 1));
        setTasks(sortedTasks);
    };

    return (
      <>
      <div className='flex flex-col'>
      <h1 className='text-xl font-bold my-7'>Task Management App</h1>
          <form onSubmit={(e) => { e.preventDefault(); addTask(); }} className='flex flex-col'>
              <input
                  type="text"
                  value={taskName}
                  onChange={(e) => setTaskName(e.target.value)}
                  placeholder="Enter task name"
              />
              <button type="submit" className='bg-amber-300 p-2 m-3'>Add Task</button>
          </form>
          <div className='flex gap-5'>
              <button onClick={sortByName}>Sort by Name</button>
              <button onClick={sortByStatus}>Sort by Status</button>
          </div>
          <ul >
              {tasks.map(task => (
                  <li key={task.id} className={task.completed ? 'completed flex gap-4 my-3 bg-slate-100 p-2' : 'flex gap-4 my-3  bg-slate-100 p-2'}>
                      {task.name}
                      {!task.completed && <button className='bg-emerald-400' onClick={() => completeTask(task.id)}>Complete</button>}
                      <button className='bg-teal-400' onClick={() => removeTask(task.id)}>Remove</button>
                  </li>
              ))}
          </ul>
      </div>
      </>
    );
};

export default TaskManager;
