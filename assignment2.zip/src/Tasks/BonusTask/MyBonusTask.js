import React, { useState } from 'react'

const MyBonusTask = () => {
    const [mytask, setMytask] = useState('');
    const [tasklist, setTasklist] = useState([]);
    function handleSubmit(e) {
        e.preventDefault();
        if (mytask === '') return;
        const addMytask = {
            id: tasklist.length + 1,
            name: mytask,
            completed: false
        }
        setTasklist([...tasklist, addMytask])
        setMytask('');
    }
    function completeTask(id){
const completedTask =  tasklist.map(task=>task.id===id ? {...task, completed:true} : task);
setTasklist(completedTask)
    }

    function removetask(id){
const removetask = tasklist.filter(task=>task.id!==id);
setTasklist(removetask);
}
function handleSorting(){
  const sortingList =   [...tasklist].sort((a,b)=> a.name.localeCompare(b.name));
setTasklist(sortingList);
console.log(tasklist);
}
    return (
        <div className='gap-3 flex justify-center items-center flex-col'>
            <h1 className='text-center font-extrabold text-2xl '>My Todo List</h1>
            <form className='flex flex-col gap-3' onSubmit={(e) => { handleSubmit(e) }}>
                <input type="text" value={mytask} onChange={(e) => { setMytask(e.target.value) }} />
                <button className='bg-emerald-300 px-4 py-2' type='submit'>Add Task</button>
            </form>
            <div className='flex gap-3'>
                <button className='text-sm font-semibold hover:text-fuchsia-400' onClick={()=>{handleSorting()}}>Sort By name</button>
            </div>
            <ul className=' my-2  gap-3 flex flex-col'>
                {tasklist.map(tasks =>
                    <li key={tasks.id} className='bg-purple-300 px-6 py-2 flex gap-5 items-center'>
                        <h6> {tasks.name}</h6>
                      {!tasks.completed &&  <button className='bg-red-600 px-4 py-2 rounded' onClick={() => { completeTask(tasks.id) }}>Completed</button>}
                        <button className='bg-red-600 px-4 py-2 rounded' onClick={() => { removetask(tasks.id) }}>Remove</button>
                    </li>
                )}
            </ul>
        </div>
    )
}

export default MyBonusTask
