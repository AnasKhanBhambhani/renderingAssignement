import React, { Component } from 'react'

export class TaskList extends Component {
    constructor() {
        super();
        this.state = {
            tasks: [
                { id: 1, text: 'task1', completed: false },
                { id: 2, text: 'task2', completed: false },
                { id: 3, text: 'task3', completed: false },
            ]
        };
    }
    completed = (id) => {
        this.setState(preState => ({
            tasks: preState.tasks.map(item =>
                item.id === id ? { ...item, completed: true } : item
            )
        }))
    }
    remove = (id) => {
        this.setState(preState => ({
            tasks: preState.tasks.filter(item => item.id !== id)
        }))
    }
    render() {
        const { tasks } = this.state;
        return (
            <div className='bg-amber-300 flex flex-col gap-3 p-16'>
                <h1 className='font-bold text-lg'>My task List</h1>

                <ul>
                    {
                        tasks.map(item => (
                            <li key={item.id} className='flex gap-4'>
                                <span className={`${item.completed ? ' line-through' : 'none'}`}>{item.text}</span>
                                <button onClick={() => this.completed(item.id)}>Completed</button>
                                <button onClick={() => this.remove(item.id)}>Remove</button>
                            </li>
                        ))
                    }
                </ul>
            </div>
        )
    }
}

export default TaskList
