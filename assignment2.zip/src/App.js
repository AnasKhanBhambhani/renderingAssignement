import './App.css'
import TaskList from './Tasks/TaskList';
import MouseTracker from './MouseTracker/MouseTracker';
import FormWithRef from './Task4/FormWithRef';
import InterectiveButton from './InterectiveButtons/InterectiveButton';
import { LifeCycle } from './Lifecycle/LifeCycle';
import TaskManager from './Tasks/BonusTask/TaskManager';
import MyBonusTask from './Tasks/BonusTask/MyBonusTask';

function App() {
  return (
    <div className='bg-orange-500 h-[100vh] w-[100vw] flex justify-center items-center'>
   <MyBonusTask/>

    </div>
  );
}

export default App;
